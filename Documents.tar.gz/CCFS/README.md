FUSE impl
